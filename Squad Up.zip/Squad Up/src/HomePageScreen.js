import React, { Component } from 'react';
import './App.css';

// UI framework component imports
import Button from 'muicss/lib/react/button';
import Container from 'muicss/lib/react/container';


export default class HomePageScreen extends Component {

  // Properties used by this component:
  // appActions, deviceInfo

  onClick_elButton2 = (ev) => {
    // Go to screen 'Log In'
    this.props.appActions.goToScreen('login');
  
  }
  
  
  render() {
    // eslint-disable-next-line no-unused-vars
    let baseStyle = {};
    // eslint-disable-next-line no-unused-vars
    let layoutFlowStyle = {};
    if (this.props.transitionId && this.props.transitionId.length > 0 && this.props.atTopOfScreenStack && this.props.transitionForward) {
      baseStyle.animation = '0.25s ease-in-out '+this.props.transitionId;
    }
    if ( !this.props.atTopOfScreenStack) {
      layoutFlowStyle.height = '100vh';
      layoutFlowStyle.overflow = 'hidden';
    }
    
    const style_background = {
        width: '100%',
        height: '100%',
     };
    const style_background_outer = {
        backgroundColor: '#f6f6f6',
        pointerEvents: 'none',
     };
    const style_button = {
        display: 'block',
        fontSize: 41.9,
        fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", "Roboto", "Oxygen", "Ubuntu", sans-serif',
        textAlign: 'center',
     };
    const style_button_outer = {
        pointerEvents: 'none',
     };
    const style_button2 = {
        display: 'block',
        fontSize: 41.9,
        fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", "Roboto", "Oxygen", "Ubuntu", sans-serif',
        textAlign: 'center',
     };
    const style_button2_outer = {
        cursor: 'pointer',
     };
    const style_textBlock = {
        fontSize: 67.0,
        fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", "Roboto", "Oxygen", "Ubuntu", sans-serif',
        fontStyle: 'italic',
        color: 'rgba(0, 0, 0, 0.8500)',
        textAlign: 'center',
        pointerEvents: 'none',
     };
    const style_textBlock2 = {
        fontSize: 75.4,
        fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", "Roboto", "Oxygen", "Ubuntu", sans-serif',
        fontWeight: 'bold',
        color: 'rgba(0, 0, 0, 0.8500)',
        textAlign: 'center',
        pointerEvents: 'none',
     };
    const style_textBlock3 = {
        fontSize: 25.1,
        fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", "Roboto", "Oxygen", "Ubuntu", sans-serif',
        color: 'rgba(0, 0, 0, 0.8500)',
        textAlign: 'center',
        pointerEvents: 'none',
     };
    const style_textBlock4 = {
        fontSize: 25.1,
        fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", "Roboto", "Oxygen", "Ubuntu", sans-serif',
        color: 'rgba(0, 0, 0, 0.8500)',
        textAlign: 'center',
        pointerEvents: 'none',
     };
    
    return (
      <Container fluid={true} className="AppScreen HomePageScreen" style={baseStyle}>
        <div className="background">
          <div className='appBg containerMinHeight elBackground' style={style_background_outer}>
            <div style={style_background} />
          
          </div>
          
        </div>
        <div className="layoutFlow" style={layoutFlowStyle}>
          <div className='elButton' style={style_button_outer}>
            <Button style={style_button}  color="accent" >
              {this.props.locStrings.start_button_767737}
            </Button>
          
          </div>
          
          <div className='elButton2' style={style_button2_outer}>
            <Button style={style_button2}  color="accent" onClick={this.onClick_elButton2} >
              {this.props.locStrings.start_button2_1004791}
            </Button>
          
          </div>
          
        </div>
        <div className="screenFgContainer">
          <div className="foreground">
            <div className='elTextBlock' style={style_textBlock}>
              <div>{this.props.locStrings.start_textblock_21918}</div>
            </div>
            <div className='elTextBlock2' style={style_textBlock2}>
              <div>{this.props.locStrings.start_textblock2_349256}</div>
            </div>
            <div className='elTextBlock3' style={style_textBlock3}>
              <div>{this.props.locStrings.start_textblock3_337859}</div>
            </div>
            <div className='elTextBlock4' style={style_textBlock4}>
              <div>{this.props.locStrings.start_textblock4_404013}</div>
            </div>
          </div>
        </div>
      </Container>
    )
  }
  

}
