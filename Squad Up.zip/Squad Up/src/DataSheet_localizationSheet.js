import DataSheetBase from './DataSheetBase.js';

export default class DataSheet_localizationSheet extends DataSheetBase {

  constructor(id, updateCb) {
    super(id, updateCb);
    this.requestedKeyPath = "";  // this value can be specified in the React Studio data sheet UI
  }

  makeDefaultItems() {
    // eslint-disable-next-line no-unused-vars
    let key = 1;
    // eslint-disable-next-line no-unused-vars
    let item;
    
    item = {};
    this.items.push(item);
    item['key'] = "homepage_button_74169";
    item['en'] = "Sign Up";
    
    item = {};
    this.items.push(item);
    item['key'] = "homepage_button2_668086";
    item['en'] = "Log In";
    
    item = {};
    this.items.push(item);
    item['key'] = "homepage_text_825964";
    item['en'] = "New text. Double-click to edit";
    
    item = {};
    this.items.push(item);
    item['key'] = "homepage_text_610710";
    item['en'] = "A revolutionary way to play sports";
    
    item = {};
    this.items.push(item);
    item['key'] = "homepage_text2_74124";
    item['en'] = "New text. Double-click to edit";
    
    item = {};
    this.items.push(item);
    item['key'] = "homepage_text2_953180";
    item['en'] = "New text. Double-click to edit";
    
    item = {};
    this.items.push(item);
    item['key'] = "homepage_text2_342081";
    item['en'] = "New text. Double-click to edit";
    
    item = {};
    this.items.push(item);
    item['key'] = "homepage_text2_814062";
    item['en'] = "Squad Up";
    
    item = {};
    this.items.push(item);
    item['key'] = "homepage_text3_258111";
    item['en'] = "New text. Double-click to edit";
    
    item = {};
    this.items.push(item);
    item['key'] = "homepage_text3_742428";
    item['en'] = "New to Squad Up?";
    
    item = {};
    this.items.push(item);
    item['key'] = "homepage_text3_893743";
    item['en'] = "New to Squad Up?";
    
    item = {};
    this.items.push(item);
    item['key'] = "homepage_text4_555533";
    item['en'] = "Already have an account?";
    
    item = {};
    this.items.push(item);
    item['key'] = "homepage_text_150876";
    item['en'] = "New text. Double-click to edit";
    
    item = {};
    this.items.push(item);
    item['key'] = "start_textblock_515382";
    item['en'] = " ";
    
    item = {};
    this.items.push(item);
    item['key'] = "start_textblock_21918";
    item['en'] = "A revolutionary way to play sports";
    
    item = {};
    this.items.push(item);
    item['key'] = "start_textblock2_349256";
    item['en'] = "Squad Up";
    
    item = {};
    this.items.push(item);
    item['key'] = "start_button_767737";
    item['en'] = "Sign Up";
    
    item = {};
    this.items.push(item);
    item['key'] = "start_button2_1004791";
    item['en'] = "Log In";
    
    item = {};
    this.items.push(item);
    item['key'] = "start_textblock3_337859";
    item['en'] = "New to Squad Up?";
    
    item = {};
    this.items.push(item);
    item['key'] = "start_textblock4_404013";
    item['en'] = "Already have an account?";
    
    item = {};
    this.items.push(item);
    item['key'] = "login1_text_532825";
    item['en'] = "New text. Double-click to edit";
    
    item = {};
    this.items.push(item);
    item['key'] = "screen2_text_466583";
    item['en'] = "username.gmail.com";
    
    item = {};
    this.items.push(item);
    item['key'] = "screen2_text2_400812";
    item['en'] = "password";
    
    item = {};
    this.items.push(item);
    item['key'] = "screen2_field_233914";
    item['en'] = "email address";
    
    item = {};
    this.items.push(item);
    item['key'] = "screen2_field2_1033294";
    item['en'] = "password";
  }

  getStringsByLanguage = () => {
    let stringsByLang = {};
    for (let row of this.items) {
      const locKey = row.key;
      for (let key in row) {
        if (key === 'key')
          continue;
        let langObj = stringsByLang[key] || {};
        langObj[locKey] = row[key];
        stringsByLang[key] = langObj;
      }
    }
    return stringsByLang;
  }

}
